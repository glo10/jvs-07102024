# Template

- [css/](./css/) : contient les fichiers CSS de l'exercice
- [data/](./data/) : les villes et les pays au format JSON et XML qui seront abordées plus tard
- [html/](./html/) : pages HTML
- [html/_partials/](./html/_partials/) : contenus partiels et isolés de bout de pages HTML qui pourront être intégrés dynamique plus tard de manière asynchrone
- **[js/](./js/) : dossier dans lequel, vous devez travailler pour écrire vos scripts JS**